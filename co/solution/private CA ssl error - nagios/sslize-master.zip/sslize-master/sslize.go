package main

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strings"

	log "github.com/sirupsen/logrus"
)

type Name struct {
	Country            string `json:"C,omitempty"`
	State              string `json:"ST,omitempty"`
	Locality           string `json:"L,omitempty"`
	Organisation       string `json:"O,omitempty"`
	OrganisationalUnit string `json:"OU,omitempty"`
	SerialNumber       string `json:"SerialNumber,omitempty"`
}

type Key struct {
	Algo string `json:"algo"`
	Size int    `json:"size"`
}

type Request struct {
	Request NewCertificateRequest `json:"request"`
}

type NewCertificateRequest struct {
	Hosts []string `json:"hosts"`
	Names []Name   `json:"names"`
	CN    string   `json:"CN"`
	Key   Key      `json:"key"`
}

type ResponseMessage struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type Response struct {
	Success  bool                   `json:"success"`
	Result   NewCertificateResponse `json:"result"`
	Errors   []ResponseMessage      `json:"errors"`
	Messages []ResponseMessage      `json:"messages"`
}
type NewCertificateResponse struct {
	Certificate string `json:"certificate"`
	Key         string `json:"private_key"`
	CSR         string `json:"certificate_request"`
	CA          string `json:"ca"`
	Serial      string `json:"serial"`
}

type ForemanResult struct {
	Results []ForemanHost `json:"results"`
}

type ForemanHost struct {
	IP   string `json:"ip"`
	IP6  string `json:"ip6"`
	Name string `json:"name"`
}

func main() {
	log.SetLevel(log.DebugLevel)
	log.WithFields(log.Fields{
		"cn":  os.Args[1],
		"san": os.Args[1:],
	}).Info("generating certificate")
	response, err := MakeCertificate(os.Args[1], os.Args[1:])
	if err != nil {
		panic(err)
	}
	if os.Args[1] == "node" {
		fmt.Printf(`mkdir -p /var/lib/cockroach/certs
cat <<CRT> /var/lib/cockroach/certs/node.crt
%s
CRT
cat <<KEY> /var/lib/cockroach/certs/node.key
%s
KEY
cat <<CA> /var/lib/cockroach/certs/ca.crt
%s
CA
chown cockroach /var/lib/cockroach/certs/node.key
chmod 0600 /var/lib/cockroach/certs/node.key
`,
			strings.TrimRight(response.Certificate, "\n"),
			strings.TrimRight(response.Key, "\n"),
			strings.TrimRight(response.CA, "\n"),
		)
	} else {
		fmt.Printf(`mkdir -p /etc/ssl/ca
cat <<CRT> /etc/ssl/ca/server.crt
%s
CRT
cat <<KEY> /etc/ssl/ca/server.key
%s
KEY
cat <<CA> /etc/ssl/ca/ca.crt
%s
CA
`,
			strings.TrimRight(response.Certificate, "\n"),
			strings.TrimRight(response.Key, "\n"),
			strings.TrimRight(response.CA, "\n"),
		)
	}
}
func foremanHosts() {

	httpClient := &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: true,
			},
		},
	}

	req, err := http.NewRequest("GET", "https://foreman.belugacdn.com/api/v2/hosts", nil)
	if err != nil {
		panic(err)
	}
	req.SetBasicAuth("cfssl", "Moo7Quoon9eif5Ufiwo")

	resp, err := httpClient.Do(req)
	if err != nil {
		panic(err)
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		panic(err)
	}

	result := &ForemanResult{}
	err = json.Unmarshal(body, result)
	if err != nil {
		panic(err)
	}
	for _, host := range result.Results {
		fmt.Printf("# %s\n", host.Name)
	}

	// Moo7Quoon9eif5Ufiwo
	//atomicxt.WriteString(fmt.Sprintf("%s-key.pem", names[0]), response.Key)
	//atomicxt.WriteString(fmt.Sprintf("%s.pem", names[0]), response.Certificate)
	//atomicxt.WriteString(fmt.Sprintf("%s.csr", names[0]), response.CSR)
}

func MakeCertificate(cn string, names []string) (*NewCertificateResponse, error) {
	cfssl_cert := os.Getenv("SSLIZE_CERT")
	if cfssl_cert == "" {
		cfssl_cert = "/etc/ssl/ca/server.crt"
	}

	cfssl_key := os.Getenv("SSLIZE_KEY")
	if cfssl_key == "" {
		cfssl_key = "/etc/ssl/ca/server.key"
	}

	cfssl_ca := os.Getenv("SSLIZE_CA")
	if cfssl_ca == "" {
		cfssl_ca = "/etc/ssl/ca/ca.pem"
	}

	cert, err := tls.LoadX509KeyPair(cfssl_cert, cfssl_key)
	if err != nil {
		log.WithFields(log.Fields{
			"cfssl-cert": cfssl_cert,
			"cfssl-key":  cfssl_key,
			"error":      err,
		}).Error("cfssl/newcert unable to load cert/key")
		return nil, err
	}

	caCert, err := ioutil.ReadFile(cfssl_ca)
	if err != nil {
		log.WithFields(log.Fields{
			"cfssl-ca": cfssl_ca,
			"error":    err,
		}).Error("cfssl/newcert unable to load ca")
		return nil, err
	}

	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(caCert)

	tlsConfig := &tls.Config{
		Certificates: []tls.Certificate{cert},
		RootCAs:      caCertPool,
	}

	tlsConfig.BuildNameToCertificate()
	transport := &http.Transport{TLSClientConfig: tlsConfig}
	client := &http.Client{Transport: transport}

	var buf bytes.Buffer

	request := Request{
		Request: NewCertificateRequest{
			Hosts: names,
			CN:    cn,
			Key: Key{
				Algo: "rsa",
				Size: 2048,
			},
			Names: []Name{
				Name{
					Organisation: "BelugaCDN",
				},
			},
		},
	}

	bytes, err := json.Marshal(request)
	if err != nil {
		log.WithFields(log.Fields{
			"error": err,
		}).Error("cfssl/newcert json.Marshal failed")
		return nil, err
	}

	buf.Write(bytes)

	resp, err := client.Post("https://influxdb-fresh.belugacdn.com:8889/api/v1/cfssl/newcert", "application/json", &buf)
	if err != nil {
		log.WithFields(log.Fields{
			"error": err,
		}).Error("cfssl/newcert client.Post failed")
		return nil, err
	}
	defer resp.Body.Close()

	data, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.WithFields(log.Fields{
			"error": err,
		}).Error("cfssl/newcert ioutil.ReadAll failed")
		return nil, err
	}

	response := Response{}
	err = json.Unmarshal(data, &response)
	if err != nil {
		log.WithFields(log.Fields{
			"error": err,
			"body":  string(data),
		}).Error("cfssl/newcert json.Unmarshal failed")
		return nil, err
	}

	for _, message := range response.Messages {
		log.WithFields(log.Fields{
			"message": message.Message,
			"code":    message.Code,
		}).Info("cfssl/newcert response message")
	}

	for _, message := range response.Errors {
		log.WithFields(log.Fields{
			"message": message.Message,
			"code":    message.Code,
		}).Error("cfssl/newcert response error")
	}

	if len(response.Errors) > 0 {
		return nil, errors.New(response.Errors[0].Message)
	}

	block, _ := pem.Decode([]byte(response.Result.Certificate))
	if block == nil {
		nErr := errors.New("failed to pem.Decode certificate")
		log.WithFields(log.Fields{
			"error": nErr,
		}).Error("cfssl/newcert json.Unmarshal failed")
		return nil, nErr

	}

	newCert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		log.WithFields(log.Fields{
			"error": err,
		}).Error("cfssl/newcert failed to parse returned certificate")
		return nil, err
	}

	response.Result.CA = string(caCert)
	response.Result.Serial = newCert.SerialNumber.String()

	return &response.Result, nil
}
