#!/bin/bash
SSLIZE_CA=/etc/ssl/ca/ca.crt \
SSLIZE_CERT=/etc/ssl/ca/server.crt \
SSLIZE_KEY=/etc/ssl/ca/server.key \
go run sslize.go $@ | cat > file
